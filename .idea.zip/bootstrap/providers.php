<?php

return [
    App\Providers\AppServiceProvider::class,
    Maatwebsite\Excel\ExcelServiceProvider::class,
];

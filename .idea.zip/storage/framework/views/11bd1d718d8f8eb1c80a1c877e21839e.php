

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-key"></i> إدارة الصلاحيات</h2>
        <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> إضافة صلاحية جديدة
        </a>
    </div>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $perms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-4 shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">
                <i class="fas fa-folder-open"></i> 
                <?php switch($module):
                    case ('patients'): ?> المرضى <?php break; ?>
                    <?php case ('doctors'): ?> الأطباء <?php break; ?>
                    <?php case ('departments'): ?> العيادات <?php break; ?>
                    <?php case ('appointments'): ?> المواعيد <?php break; ?>
                    <?php case ('visits'): ?> الزيارات <?php break; ?>
                    <?php case ('surgeries'): ?> العمليات <?php break; ?>
                    <?php case ('radiology'): ?> الأشعة <?php break; ?>
                    <?php case ('tests'): ?> التحاليل <?php break; ?>
                    <?php case ('inquiries'): ?> الاستعلامات <?php break; ?>
                    <?php default: ?> <?php echo e($module); ?>

                <?php endswitch; ?>
                <span class="badge bg-light text-dark ms-2"><?php echo e($perms->count()); ?></span>
            </h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 50%">اسم الصلاحية</th>
                            <th style="width: 30%">الأدوار المرتبطة</th>
                            <th style="width: 20%">الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <i class="fas fa-shield-alt text-primary"></i>
                                <code><?php echo e($permission->name); ?></code>
                            </td>
                            <td>
                                <?php if($permission->roles_count > 0): ?>
                                    <span class="badge bg-success"><?php echo e($permission->roles_count); ?> دور</span>
                                <?php else: ?>
                                    <span class="text-muted">غير مستخدمة</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($permission->roles_count == 0): ?>
                                <form action="<?php echo e(route('permissions.destroy', $permission)); ?>" 
                                      method="POST" 
                                      class="d-inline"
                                      onsubmit="return confirm('هل أنت متأكد من حذف هذه الصلاحية؟')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-sm btn-outline-danger" 
                                            title="حذف">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php else: ?>
                                <button class="btn btn-sm btn-outline-secondary" disabled title="لا يمكن الحذف - مرتبطة بأدوار">
                                    <i class="fas fa-lock"></i>
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<style>
    code {
        background-color: #f8f9fa;
        padding: 0.2rem 0.4rem;
        border-radius: 3px;
        color: #d63384;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\hospital-system\resources\views/permissions/index.blade.php ENDPATH**/ ?>
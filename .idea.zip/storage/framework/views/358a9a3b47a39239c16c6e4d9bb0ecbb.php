<!-- resources/views/visits/edit.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>
                    <i class="fas fa-edit me-2"></i>
                    تعديل الزيارة
                </h2>
                <a href="<?php echo e(route('visits.show', $visit)); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-right me-2"></i>العودة للتفاصيل
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">بيانات الزيارة</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('visits.update', $visit)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">
                            <!-- المريض -->
                            <div class="col-md-6 mb-3">
                                <label for="patient_id" class="form-label">المريض *</label>
                                <select class="form-select <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="patient_id" name="patient_id" required>
                                    <option value="">اختر المريض</option>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($patient->id); ?>"
                                                <?php echo e(old('patient_id', $visit->patient_id) == $patient->id ? 'selected' : ''); ?>>
                                            <?php echo e($patient->user->name); ?> - <?php echo e($patient->user->phone); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- الطبيب -->
                            <div class="col-md-6 mb-3">
                                <label for="doctor_id" class="form-label">الطبيب *</label>
                                <select class="form-select <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="doctor_id" name="doctor_id" required>
                                    <option value="">اختر الطبيب</option>
                                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($doctor->id); ?>"
                                                <?php echo e(old('doctor_id', $visit->doctor_id) == $doctor->id ? 'selected' : ''); ?>>
                                            د. <?php echo e($doctor->user->name); ?> - <?php echo e($doctor->specialization); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <!-- العيادة -->
                            <div class="col-md-6 mb-3">
                                <label for="department_id" class="form-label">العيادة *</label>
                                <select class="form-select <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="department_id" name="department_id" required>
                                    <option value="">اختر العيادة</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>"
                                                <?php echo e(old('department_id', $visit->department_id) == $department->id ? 'selected' : ''); ?>>
                                            <?php echo e($department->name); ?> - <?php echo e($department->room_number); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- نوع الزيارة -->
                            <div class="col-md-6 mb-3">
                                <label for="visit_type" class="form-label">نوع الزيارة *</label>
                                <select class="form-select <?php $__errorArgs = ['visit_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="visit_type" name="visit_type" required>
                                    <option value="">اختر نوع الزيارة</option>
                                    <option value="checkup" <?php echo e(old('visit_type', $visit->visit_type) == 'checkup' ? 'selected' : ''); ?>>كشف دوري</option>
                                    <option value="followup" <?php echo e(old('visit_type', $visit->visit_type) == 'followup' ? 'selected' : ''); ?>>متابعة</option>
                                    <option value="emergency" <?php echo e(old('visit_type', $visit->visit_type) == 'emergency' ? 'selected' : ''); ?>>طوارئ</option>
                                    <option value="surgery" <?php echo e(old('visit_type', $visit->visit_type) == 'surgery' ? 'selected' : ''); ?>>عملية جراحية</option>
                                    <option value="lab" <?php echo e(old('visit_type', $visit->visit_type) == 'lab' ? 'selected' : ''); ?>>مختبر</option>
                                    <option value="radiology" <?php echo e(old('visit_type', $visit->visit_type) == 'radiology' ? 'selected' : ''); ?>>أشعة</option>
                                </select>
                                <?php $__errorArgs = ['visit_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <!-- تاريخ الزيارة -->
                            <div class="col-md-6 mb-3">
                                <label for="visit_date" class="form-label">تاريخ الزيارة *</label>
                                <input type="date"
                                       class="form-control <?php $__errorArgs = ['visit_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="visit_date"
                                       name="visit_date"
                                       value="<?php echo e(old('visit_date', $visit->visit_date ? $visit->visit_date->format('Y-m-d') : '')); ?>"
                                       required>
                                <?php $__errorArgs = ['visit_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- وقت الزيارة -->
                            <div class="col-md-6 mb-3">
                                <label for="visit_time" class="form-label">وقت الزيارة *</label>
                                <input type="time"
                                       class="form-control <?php $__errorArgs = ['visit_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="visit_time"
                                       name="visit_time"
                                       value="<?php echo e(old('visit_time', $visit->visit_time ? $visit->visit_time->format('H:i') : '')); ?>"
                                       required>
                                <?php $__errorArgs = ['visit_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- الشكوى الرئيسية -->
                        <div class="mb-3">
                            <label for="chief_complaint" class="form-label">الشكوى الرئيسية *</label>
                            <textarea class="form-control <?php $__errorArgs = ['chief_complaint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="chief_complaint"
                                      name="chief_complaint"
                                      rows="3"
                                      placeholder="اذكر الشكوى الرئيسية للمريض..."
                                      required><?php echo e(old('chief_complaint', $visit->chief_complaint)); ?></textarea>
                            <?php $__errorArgs = ['chief_complaint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- باقي الحقول -->
                        <div class="row">
                            <!-- التشخيص -->
                            <div class="col-md-6 mb-3">
                                <label for="diagnosis" class="form-label">التشخيص</label>
                                <textarea class="form-control <?php $__errorArgs = ['diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                          id="diagnosis"
                                          name="diagnosis"
                                          rows="3"
                                          placeholder="اكتب التشخيص..."><?php echo e(old('diagnosis', is_array($visit->diagnosis) ? ($visit->diagnosis['description'] ?? '') : $visit->diagnosis)); ?></textarea>
                                <?php $__errorArgs = ['diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- العلاج -->
                            <div class="col-md-6 mb-3">
                                <label for="treatment" class="form-label">العلاج</label>
                                <textarea class="form-control <?php $__errorArgs = ['treatment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                          id="treatment"
                                          name="treatment"
                                          rows="3"
                                          placeholder="اكتب العلاج المقترح..."><?php echo e(old('treatment', $visit->treatment)); ?></textarea>
                                <?php $__errorArgs = ['treatment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- الوصفة الطبية -->
                        <div class="mb-3">
                            <label for="prescription" class="form-label">الوصفة الطبية</label>
                            <textarea class="form-control <?php $__errorArgs = ['prescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="prescription"
                                      name="prescription"
                                      rows="4"
                                      placeholder="اكتب الوصفة الطبية..."><?php echo e(old('prescription', $visit->prescription)); ?></textarea>
                            <?php $__errorArgs = ['prescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- الملاحظات -->
                        <div class="mb-3">
                            <label for="notes" class="form-label">ملاحظات إضافية</label>
                            <textarea class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="notes"
                                      name="notes"
                                      rows="3"
                                      placeholder="أي ملاحظات إضافية..."><?php echo e(old('notes', $visit->notes)); ?></textarea>
                            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- الحالة -->
                        <div class="mb-3">
                            <label for="status" class="form-label">حالة الزيارة</label>
                            <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="status" name="status">
                                <option value="scheduled" <?php echo e(old('status', $visit->status) == 'scheduled' ? 'selected' : ''); ?>>مجدولة</option>
                                <option value="in_progress" <?php echo e(old('status', $visit->status) == 'in_progress' ? 'selected' : ''); ?>>قيد التنفيذ</option>
                                <option value="completed" <?php echo e(old('status', $visit->status) == 'completed' ? 'selected' : ''); ?>>مكتملة</option>
                                <option value="cancelled" <?php echo e(old('status', $visit->status) == 'cancelled' ? 'selected' : ''); ?>>ملغاة</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>حفظ التغييرات
                            </button>
                            <a href="<?php echo e(route('visits.show', $visit)); ?>" class="btn btn-secondary">
                                <i class="fas fa-times me-2"></i>إلغاء
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- معلومات سريعة -->
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0">
                        <i class="fas fa-info-circle me-2"></i>
                        معلومات الزيارة
                    </h6>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <h6>تفاصيل الزيارة الحالية:</h6>
                        <p class="mb-1"><strong>المريض:</strong> <?php echo e($visit->patient->user->name); ?></p>
                        <p class="mb-1"><strong>الطبيب:</strong> د. <?php echo e($visit->doctor?->user?->name ?? 'غير محدد'); ?></p>
                        <p class="mb-1"><strong>العيادة:</strong> <?php echo e($visit->department->name); ?></p>
                        <p class="mb-1"><strong>التاريخ:</strong> <?php echo e($visit->visit_date ? $visit->visit_date->format('Y-m-d') : 'غير محدد'); ?></p>
                        <p class="mb-1"><strong>الوقت:</strong> <?php echo e($visit->visit_time ? $visit->visit_time->format('H:i') : 'غير محدد'); ?></p>
                        <p class="mb-0"><strong>الحالة:</strong>
                            <span class="badge bg-<?php echo e($visit->status == 'completed' ? 'success' : ($visit->status == 'in_progress' ? 'warning' : 'secondary')); ?>">
                                <?php echo e($visit->status_text); ?>

                            </span>
                        </p>
                    </div>

                    <?php if($visit->appointment): ?>
                    <div class="alert alert-success">
                        <h6><i class="fas fa-calendar-check me-2"></i>مأخوذة من موعد</h6>
                        <p class="mb-0">هذه الزيارة تم تحويلها من موعد طبي مسبق.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\hospital-system\resources\views/visits/edit.blade.php ENDPATH**/ ?>
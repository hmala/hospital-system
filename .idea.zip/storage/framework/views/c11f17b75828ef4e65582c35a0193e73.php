<!-- resources/views/visits/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2><i class="fas fa-history me-2"></i>سجل الزيارات</h2>
                <a href="<?php echo e(route('visits.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>تسجيل زيارة جديدة
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- قسم الزيارات التي تحتاج حجز عملية -->
    <?php if($needsSurgeryVisits->count() > 0): ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-warning shadow-sm">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        زيارات تحتاج حجز عملية (<?php echo e($needsSurgeryVisits->count()); ?>)
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>التاريخ</th>
                                    <th>المريض</th>
                                    <th>الطبيب المحول</th>
                                    <th>ملاحظات العملية</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $needsSurgeryVisits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><strong><?php echo e($visit->visit_date->format('Y-m-d')); ?></strong></td>
                                    <td>
                                        <a href="<?php echo e(route('patients.show', $visit->patient)); ?>" class="text-decoration-none">
                                            <?php echo e($visit->patient->user->name); ?>

                                        </a>
                                        <br>
                                        <small class="text-muted"><?php echo e($visit->patient->user->phone); ?></small>
                                    </td>
                                    <td>د. <?php echo e($visit->doctor->user->name); ?></td>
                                    <td>
                                        <small class="text-muted"><?php echo e(Str::limit($visit->surgery_notes, 100)); ?></small>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('surgeries.create', ['visit_id' => $visit->id, 'patient_id' => $visit->patient_id, 'doctor_id' => $visit->doctor_id, 'department_id' => $visit->department_id])); ?>" 
                                           class="btn btn-sm btn-primary">
                                            <i class="fas fa-procedures me-1"></i>
                                            حجز العملية
                                        </a>
                                        <a href="<?php echo e(route('visits.show', $visit)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye me-1"></i>
                                            عرض الزيارة
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- إحصائيات سريعة -->
    <div class="row mb-4">
        <div class="col-md-2 col-6">
            <div class="card bg-primary text-white">
                <div class="card-body text-center py-3">
                    <h5 class="mb-0"><?php echo e($visits->total()); ?></h5>
                    <small>إجمالي الزيارات</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="card bg-success text-white">
                <div class="card-body text-center py-3">
                    <h5 class="mb-0"><?php echo e($visits->getCollection()->where('visit_date', today()->format('Y-m-d'))->count()); ?></h5>
                    <small>زيارات اليوم</small>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>التاريخ</th>
                                    <th>المريض</th>
                                    <th>الطبيب</th>
                                    <th>نوع الزيارة</th>
                                    <th>حالة الزيارة</th>
                                    <th>الشكوى الرئيسية</th>
                                    <th>التشخيص</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><strong><?php echo e($visit->visit_date ? $visit->visit_date->format('Y-m-d') : 'غير محدد'); ?></strong></td>
                                    <td>
                                        <a href="<?php echo e(route('patients.show', $visit->patient)); ?>" class="text-decoration-none">
                                            <?php echo e($visit->patient->user->name); ?>

                                        </a>
                                        <br>
                                        <small class="text-muted"><?php echo e($visit->patient->user->phone); ?></small>
                                    </td>
                                    <td>د. <?php echo e($visit->doctor?->user?->name ?? 'غير محدد'); ?></td>
                                    <td><span class="badge bg-info"><?php echo e($visit->visit_type_text); ?></span></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($visit->status == 'completed' ? 'success' : ($visit->status == 'in_progress' ? 'warning' : ($visit->status == 'cancelled' ? 'danger' : 'secondary'))); ?>">
                                            <?php echo e($visit->status_text); ?>

                                        </span>
                                    </td>
                                    <td><small class="text-muted"><?php echo e(Str::limit($visit->chief_complaint, 50)); ?></small></td>
                                    <td><?php if($visit->diagnosis && isset($visit->diagnosis['description'])): ?><small class="text-success"><?php echo e(Str::limit($visit->diagnosis['description'], 50)); ?></small><?php else: ?><span class="text-muted">---</span><?php endif; ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?php echo e(route('visits.show', $visit)); ?>" class="btn btn-info" title="عرض"><i class="fas fa-eye"></i></a>
                                            <a href="<?php echo e(route('visits.edit', $visit)); ?>" class="btn btn-warning" title="تعديل"><i class="fas fa-edit"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="fas fa-history fa-3x mb-3"></i><br>لا توجد زيارات مسجلة حتى الآن
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-4"><?php echo e($visits->links()); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\hospital-system\resources\views/visits/index.blade.php ENDPATH**/ ?>
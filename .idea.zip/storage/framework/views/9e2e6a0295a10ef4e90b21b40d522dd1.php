<!-- resources/views/radiology/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2><i class="fas fa-x-ray me-2"></i>إدارة طلبات الإشعة</h2>
                <?php if(Auth::user()->isAdmin() || Auth::user()->isReceptionist() || Auth::user()->isDoctor()): ?>
                <a href="<?php echo e(route('radiology.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>طلب إشعة جديد
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- إحصائيات سريعة -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card stat-card bg-patient text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title">معلقة</h6>
                            <h3><?php echo e($requests->where('status', 'pending')->count()); ?></h3>
                        </div>
                        <i class="fas fa-clock fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-appointment text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title">مجدولة</h6>
                            <h3><?php echo e($requests->where('status', 'scheduled')->count()); ?></h3>
                        </div>
                        <i class="fas fa-calendar-check fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-doctor text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title">قيد التنفيذ</h6>
                            <h3><?php echo e($requests->where('status', 'in_progress')->count()); ?></h3>
                        </div>
                        <i class="fas fa-play fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-department text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title">مكتملة</h6>
                            <h3><?php echo e($requests->where('status', 'completed')->count()); ?></h3>
                        </div>
                        <i class="fas fa-check-circle fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- جدول طلبات الإشعة -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">طلبات الإشعة</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>المريض</th>
                                    <th>نوع الإشعة</th>
                                    <th>الطبيب المطلب</th>
                                    <th>الأولوية</th>
                                    <th>الحالة</th>
                                    <th>تاريخ الطلب</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <strong><?php echo e($request->patient->user->name); ?></strong><br>
                                        <small class="text-muted"><?php echo e($request->patient->user->phone ?? 'لا يوجد رقم'); ?></small>
                                    </td>
                                    <td>
                                        <strong><?php echo e($request->radiologyType->name); ?></strong><br>
                                        <small class="text-muted"><?php echo e($request->radiologyType->code); ?></small>
                                    </td>
                                    <td>د. <?php echo e($request->doctor->user->name); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($request->priority_color); ?>">
                                            <?php echo e($request->priority_text); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($request->status_color); ?>">
                                            <?php echo e($request->status_text); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($request->requested_date->format('Y-m-d H:i')); ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?php echo e(route('radiology.show', $request)); ?>" class="btn btn-info" title="عرض">
                                                <i class="fas fa-eye"></i>
                                            </a>

                                            <?php if($request->status === 'completed' && $request->result): ?>
                                            <a href="<?php echo e(route('radiology.print', $request)); ?>" target="_blank" class="btn btn-success" title="طباعة">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            <?php endif; ?>

                                            <?php if(Auth::user()->isAdmin() || Auth::user()->isReceptionist()): ?>
                                            <?php if($request->status === 'pending'): ?>
                                            <a href="<?php echo e(route('radiology.edit', $request)); ?>" class="btn btn-warning" title="تعديل">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('radiology.destroy', $request)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger" title="حذف" onclick="return confirm('هل أنت متأكد من حذف هذا الطلب؟')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if(Auth::user()->hasRole('radiology_staff') && $request->canBePerformed()): ?>
                                            <form action="<?php echo e(route('radiology.start', $request)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-success" title="بدء الإجراء">
                                                    <i class="fas fa-play"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>

                                            <?php if($request->status === 'in_progress' && Auth::user()->hasRole('radiology_staff')): ?>
                                            <form action="<?php echo e(route('radiology.complete', $request)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-primary" title="إكمال">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="fas fa-x-ray fa-3x mb-3"></i><br>لا توجد طلبات إشعة
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($requests->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\hospital-system\resources\views/radiology/index.blade.php ENDPATH**/ ?>
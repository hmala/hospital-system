

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">
                        <i class="fas fa-clinic-medical me-2"></i>
                        العيادات المتاحة
                    </h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card h-100 border-primary">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-clinic-medical me-2"></i>
                                        <?php echo e($department->name); ?>

                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-6">
                                            <strong>النوع:</strong><br>
                                            <?php echo e($department->type); ?>

                                        </div>
                                        <div class="col-6">
                                            <strong>الغرفة:</strong><br>
                                            <?php echo e($department->room_number); ?>

                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-6">
                                            <strong>رسوم الاستشارة:</strong><br>
                                            <?php echo e(number_format($department->consultation_fee, 2)); ?> ريال
                                        </div>
                                        <div class="col-6">
                                            <strong>مواعيد اليوم:</strong><br>
                                            <span class="badge bg-info"><?php echo e($department->today_appointments_count); ?></span>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-12">
                                            <strong>ساعات العمل:</strong><br>
                                            <?php echo e($department->working_hours_start); ?> - <?php echo e($department->working_hours_end); ?>

                                        </div>
                                    </div>
                                    <?php if($department->doctors->count() > 0): ?>
                                    <hr>
                                    <div class="row">
                                        <div class="col-12">
                                            <strong>الأطباء (<?php echo e($department->doctors->count()); ?>):</strong><br>
                                            <small class="text-muted">
                                                <?php $__currentLoopData = $department->doctors->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($doctor->name); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($department->doctors->count() > 3): ?>
                                                و <?php echo e($department->doctors->count() - 3); ?> آخرين
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="card-footer text-center">
                                    <small class="text-muted">
                                        الحد الأقصى للمرضى يومياً: <?php echo e($department->max_patients_per_day); ?>

                                    </small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <div class="alert alert-info text-center">
                                <i class="fas fa-info-circle fa-2x mb-3"></i>
                                <h5>لا توجد عيادات متاحة حالياً</h5>
                                <p>يرجى المحاولة لاحقاً أو الاتصال بالمستشفى للمزيد من المعلومات.</p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php if($departments->hasPages()): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($departments->links()); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\hospital-system\resources\views/departments/public_index.blade.php ENDPATH**/ ?>
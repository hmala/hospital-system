<!-- resources/views/departments/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2><i class="fas fa-clinic-medical me-2"></i>إدارة العيادات</h2>
                <a href="<?php echo e(route('departments.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>إضافة عيادة جديدة
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>اسم العيادة</th>
                                    <th>النوع</th>
                                    <th>رقم الغرفة</th>
                                    <th>أجر الكشف</th>
                                    <th>أوقات العمل</th>
                                    <th>مواعيد اليوم</th>
                                    <th>الحالة</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><strong><?php echo e($department->name); ?></strong></td>
                                    <td><span class="badge bg-info"><?php echo e($department->getTypeText()); ?></span></td>
                                    <td><?php echo e($department->room_number); ?></td>
                                    <td><span class="text-success"><?php echo e(number_format($department->consultation_fee)); ?> د.ع</span></td>
                                    <td><small><?php echo e($department->working_hours_start ? $department->working_hours_start->format('h:i A') : 'غير محدد'); ?> - <?php echo e($department->working_hours_end ? $department->working_hours_end->format('h:i A') : 'غير محدد'); ?></small></td>
                                    <td><span class="badge bg-primary"><?php echo e($department->today_appointments_count); ?></span></td>
                                    <td><?php if($department->is_active): ?><span class="badge bg-success">نشط</span><?php else: ?><span class="badge bg-danger">غير نشط</span><?php endif; ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?php echo e(route('departments.show', $department)); ?>" class="btn btn-info" title="عرض"><i class="fas fa-eye"></i></a>
                                            <a href="<?php echo e(route('departments.edit', $department)); ?>" class="btn btn-warning" title="تعديل"><i class="fas fa-edit"></i></a>
                                            <form action="<?php echo e(route('departments.destroy', $department)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger" title="حذف" onclick="return confirm('هل أنت متأكد من حذف العيادة؟')"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted py-4">
                                        <i class="fas fa-clinic-medical fa-3x mb-3"></i><br>لا توجد عيادات مضافة حتى الآن
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center mt-4"><?php echo e($departments->links()); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\hospital-system\resources\views/departments/index.blade.php ENDPATH**/ ?>
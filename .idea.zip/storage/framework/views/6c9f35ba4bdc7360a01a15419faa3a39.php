

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>
                    <i class="fas fa-clipboard-list me-2"></i>
                    إدارة الطلبات الطبية
                </h2>
                <small class="text-muted">مرحباً <?php echo e(auth()->user()->name); ?></small>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- فلاتر الطلبات -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-filter me-2"></i>
                        فلترة الطلبات
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $allowedTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allowedType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-2">
                            <a href="<?php echo e(route('staff.requests.index', $allowedType)); ?>"
                               class="btn btn-outline-<?php echo e($type == $allowedType ? 'primary' : 'secondary'); ?> w-100">
                                <i class="fas fa-<?php echo e($allowedType == 'lab' ? 'flask' : ($allowedType == 'radiology' ? 'x-ray' : 'pills')); ?> me-2"></i>
                                <?php echo e($allowedType == 'lab' ? 'المختبر' : ($allowedType == 'radiology' ? 'الأشعة' : 'الصيدلية')); ?>

                                <?php if($type == $allowedType): ?>
                                    <span class="badge bg-primary ms-2"><?php echo e($requests->total()); ?></span>
                                <?php endif; ?>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-2">
                            <a href="<?php echo e(route('staff.requests.index')); ?>"
                               class="btn btn-outline-<?php echo e(!$type ? 'primary' : 'secondary'); ?> w-100">
                                <i class="fas fa-list me-2"></i>
                                الكل
                                <?php if(!$type): ?>
                                    <span class="badge bg-primary ms-2"><?php echo e($requests->total()); ?></span>
                                <?php endif; ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- قائمة الطلبات -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-tasks me-2"></i>
                        <?php echo e($type ? ($type == 'lab' ? 'طلبات المختبر' : ($type == 'radiology' ? 'طلبات الأشعة' : 'طلبات الصيدلية')) : 'جميع الطلبات'); ?>

                    </h5>
                </div>
                <div class="card-body">
                    <?php if($requests->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>رقم الطلب</th>
                                        <th>المريض</th>
                                        <th>الطبيب</th>
                                        <th>نوع الطلب</th>
                                        <th>تاريخ الطلب</th>
                                        <th>الحالة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($request->id); ?></td>
                                        <td><?php echo e($request->visit?->patient?->user?->name ?? 'غير محدد'); ?></td>
                                        <td>د. <?php echo e($request->visit?->doctor?->user?->name ?? 'غير محدد'); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($request->type == 'lab' ? 'primary' : ($request->type == 'radiology' ? 'info' : 'success')); ?>">
                                                <?php echo e($request->type_text); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($request->created_at->format('Y-m-d H:i')); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($request->status == 'completed' ? 'success' : ($request->status == 'pending' ? 'warning' : 'info')); ?>">
                                                <?php echo e($request->status_text); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <?php if($request->type == 'radiology'): ?>
                                                    <?php
                                                        // البحث عن طلب الأشعة المرتبط بنفس الزيارة
                                                        $radiologyRequest = \App\Models\RadiologyRequest::where('visit_id', $request->visit_id)
                                                            ->latest('created_at')
                                                            ->first();
                                                        
                                                        // إذا لم نجد سجل في radiology_requests، نحاول إنشاءه من بيانات الطلب
                                                        if (!$radiologyRequest && $request->details && isset($request->details['radiology_type_id'])) {
                                                            try {
                                                                $radiologyRequest = \App\Models\RadiologyRequest::create([
                                                                    'visit_id' => $request->visit_id,
                                                                    'patient_id' => $request->visit->patient_id ?? null,
                                                                    'doctor_id' => $request->visit->doctor_id ?? null,
                                                                    'radiology_type_id' => $request->details['radiology_type_id'],
                                                                    'requested_date' => $request->created_at,
                                                                    'status' => $request->status,
                                                                    'priority' => $request->details['priority'] ?? 'normal',
                                                                    'clinical_indication' => $request->description ?? null,
                                                                ]);
                                                            } catch (\Exception $e) {
                                                                // في حالة فشل الإنشاء، نستمر بدون إنشاء
                                                            }
                                                        }
                                                    ?>
                                                    <?php if($radiologyRequest): ?>
                                                        <a href="<?php echo e(route('radiology.show', $radiologyRequest->id)); ?>"
                                                           class="btn btn-outline-primary"
                                                           title="عرض تفاصيل الأشعة">
                                                            <i class="fas fa-x-ray"></i>
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('staff.requests.show', $request)); ?>"
                                                           class="btn btn-outline-primary"
                                                           title="عرض الطلب">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('staff.requests.show', $request)); ?>"
                                                       class="btn btn-outline-primary"
                                                       title="عرض">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if($request->status == 'completed' && $request->type == 'lab'): ?>
                                                    <a href="<?php echo e(route('staff.requests.print', $request)); ?>"
                                                       class="btn btn-outline-success"
                                                       target="_blank"
                                                       title="طباعة النتائج">
                                                        <i class="fas fa-print"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if($request->status == 'completed' && $request->type == 'radiology' && $radiologyRequest && $radiologyRequest->result): ?>
                                                    <a href="<?php echo e(route('radiology.print', $radiologyRequest->id)); ?>"
                                                       class="btn btn-outline-success"
                                                       target="_blank"
                                                       title="طباعة نتائج الأشعة">
                                                        <i class="fas fa-print"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($requests->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-clipboard fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">لا توجد طلبات</h5>
                            <p class="text-muted">
                                <?php echo e($type ? 'لا توجد طلبات في هذا القسم' : 'لا توجد طلبات متاحة لك'); ?>

                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\hospital-system\resources\views/staff/requests/index.blade.php ENDPATH**/ ?>
@extends('layouts.app')

@section('styles')
<style>
.step-wizard {
    margin-bottom: 40px;
    padding: 25px 35px;
    background: white;
    border-radius: 12px;
    border: 1px solid #e9ecef;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}
.progress-header {
    text-align: center;
    margin-bottom: 20px;
}
.progress-percent-text {
    font-size: 1.1rem;
    font-weight: 600;
    color: #667eea;
    margin-bottom: 15px;
}
.progress-bar-container {
    width: 100%;
    height: 30px;
    background: #e9ecef;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
    position: relative;
    display: block !important;
}
.progress-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    border-radius: 15px;
    transition: width 0.5s ease;
    position: relative;
    box-shadow: 0 2px 10px rgba(102, 126, 234, 0.5);
    display: block !important;
    min-width: 5%;
}
.progress-bar-fill::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(180deg, rgba(255,255,255,0.3) 0%, transparent 100%);
    border-radius: 15px;
}
.progress-step-info {
    margin-top: 15px;
    text-align: center;
    color: #6c757d;
    font-size: 0.95rem;
}
.tab-content {
    padding: 30px 20px;
    min-height: 400px;
}
.section-divider {
    border-top: 2px solid #e9ecef;
    margin: 30px 0;
    position: relative;
}
.section-divider::before {
    content: attr(data-title);
    position: absolute;
    top: -12px;
    left: 20px;
    background: white;
    padding: 0 10px;
    color: #6c757d;
    font-size: 0.85rem;
    font-weight: 600;
}
/* Room Cards Styles */
.room-card {
    transition: all 0.3s ease;
    border-width: 2px !important;
}
.room-card[data-available="1"]:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}
.room-card.border-4 {
    border-width: 4px !important;
}
.room-card .card-header {
    transition: all 0.3s ease;
}
.room-card[data-available="0"] {
    cursor: not-allowed !important;
}
.room-card[data-available="1"] {
    cursor: pointer;
}

</style>
@endsection

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="mb-4">
                <i class="fas fa-procedures me-2 text-primary"></i>
                حجز عملية جراحية جديدة
            </h2>
            
            <!-- مؤشر الخطوات -->
            <div class="step-wizard" style="background: #f8f9fa; border: 2px solid #dee2e6; padding: 30px;">
                <div class="progress-header">
                    <div class="progress-percent-text" id="progressPercentText" style="color: #667eea; font-size: 1.3rem; font-weight: bold; margin-bottom: 15px;">33% اكتمال</div>
                    <div class="progress-bar-container" style="width: 100%; height: 35px; background: #dee2e6; border-radius: 20px; overflow: hidden; margin-bottom: 10px;">
                        <div class="progress-bar-fill" id="progressBarFill" style="width: 33%; height: 100%; background: linear-gradient(90deg, #667eea 0%, #1262da 100%); border-radius: 20px;"></div>
                    </div>
                    <div class="progress-step-info" style="color: #495057; font-size: 1rem;">
                        الخطوة <strong id="currentStepNum">1</strong> من <strong>3</strong>: <span id="stepName">المريض والعملية</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
            <form action="{{ route('surgeries.store') }}" method="POST" id="surgeryForm" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="visit_id" value="{{ request('visit_id') }}">
                
                <!-- التبويبات -->
                <ul class="nav nav-tabs" id="surgeryTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="step1-tab" data-bs-toggle="tab" data-bs-target="#step1" type="button" role="tab">الخطوة 1</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="step2-tab" data-bs-toggle="tab" data-bs-target="#step2" type="button" role="tab">الخطوة 2</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="step3-tab" data-bs-toggle="tab" data-bs-target="#step3" type="button" role="tab">الخطوة 3</button>
                    </li>
                </ul>
                <div class="tab-content" id="surgeryTabContent">
                    <!-- الخطوة 1: بيانات المريض والعملية -->
                    <div class="tab-pane fade show active" id="step1" role="tabpanel">
                        <h5 class="mb-4 text-primary">
                            <i class="fas fa-user-injured me-2"></i>
                            بيانات المريض والعملية
                        </h5>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="patient_id" class="form-label fw-bold">
                                        <i class="fas fa-user me-1 text-primary"></i>
                                        المريض <span class="text-danger">*</span>
                                    </label>
                                    <select name="patient_id" id="patient_id" class="form-select form-select-lg @error('patient_id') is-invalid @enderror" required autofocus>
                                        <option value="">اختر المريض</option>
                                        @foreach($patients as $patient)
                                            <option value="{{ $patient->id }}" {{ (old('patient_id', request('patient_id')) == $patient->id) ? 'selected' : '' }}>
                                                {{ $patient->user->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('patient_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="blood_group" class="form-label fw-bold">
                                        <i class="fas fa-tint me-1 text-danger"></i>
                                        مجموعة الدم
                                    </label>
                                    <select name="blood_group" id="blood_group" class="form-select form-select-lg @error('blood_group') is-invalid @enderror">
                                        <option value="">اختر مجموعة الدم</option>
                                        <option value="A+" {{ old('blood_group') == 'A+' ? 'selected' : '' }}>A+</option>
                                        <option value="A-" {{ old('blood_group') == 'A-' ? 'selected' : '' }}>A-</option>
                                        <option value="B+" {{ old('blood_group') == 'B+' ? 'selected' : '' }}>B+</option>
                                        <option value="B-" {{ old('blood_group') == 'B-' ? 'selected' : '' }}>B-</option>
                                        <option value="AB+" {{ old('blood_group') == 'AB+' ? 'selected' : '' }}>AB+</option>
                                        <option value="AB-" {{ old('blood_group') == 'AB-' ? 'selected' : '' }}>AB-</option>
                                        <option value="O+" {{ old('blood_group') == 'O+' ? 'selected' : '' }}>O+</option>
                                        <option value="O-" {{ old('blood_group') == 'O-' ? 'selected' : '' }}>O-</option>
                                    </select>
                                    @error('blood_group')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="surgery_category" class="form-label fw-bold">
                                        <i class="fas fa-folder me-1 text-warning"></i>
                                        صنف العملية <span class="text-danger">*</span>
                                    </label>
                                    <select name="surgery_category" id="surgery_category" 
                                            class="form-select form-select-lg @error('surgery_category') is-invalid @enderror" 
                                            required>
                                        <option value="">-- اختر صنف العملية --</option>
                                        @foreach($surgicalOperations->unique('category')->pluck('category') as $category)
                                            <option value="{{ $category }}" {{ old('surgery_category') == $category ? 'selected' : '' }}>
                                                {{ $category }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('surgery_category')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="surgical_operation_id" class="form-label fw-bold">
                                        <i class="fas fa-stethoscope me-1 text-info"></i>
                                        نوع العملية <span class="text-danger">*</span>
                                    </label>
                                    <select name="surgical_operation_id" id="surgical_operation_id" 
                                            class="form-select form-select-lg @error('surgical_operation_id') is-invalid @enderror" 
                                            required>
                                        <option value="">-- اختر نوع العملية --</option>
                                        @foreach($surgicalOperations as $operation)
                                            <option value="{{ $operation->id }}" 
                                                    data-category="{{ $operation->category }}"
                                                    data-fee="{{ $operation->fee }}"
                                                    {{ old('surgical_operation_id') == $operation->id ? 'selected' : '' }}>
                                                {{ $operation->name }}
                                                @if($operation->fee > 0)
                                                    ({{ number_format($operation->fee, 0) }} د.ع)
                                                @endif
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('surgical_operation_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label class="form-label fw-bold">
                                        <i class="fas fa-user-doctor me-1 text-info"></i>
                                        الطبيب المرسل <span class="text-danger">*</span>
                                    </label>
                                    <div class="mb-3">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="referring_doctor_type" id="referring_internal" value="internal" {{ old('referring_doctor_type', 'internal') == 'internal' ? 'checked' : '' }}>
                                            <label class="form-check-label" for="referring_internal">
                                                <i class="fas fa-hospital me-1 text-primary"></i>
                                                من المستشفى
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="referring_doctor_type" id="referring_external" value="external" {{ old('referring_doctor_type') == 'external' ? 'checked' : '' }}>
                                            <label class="form-check-label" for="referring_external">
                                                <i class="fas fa-user-plus me-1 text-warning"></i>
                                                طبيب خارجي
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <!-- قائمة الأطباء الداخليين (نحفظ الاسم مباشرة) -->
                                    <div id="internal_doctor_select">
                                        <select name="referring_doctor_name" id="referring_doctor_name_select" class="form-select form-select-lg @error('referring_doctor_name') is-invalid @enderror" required>
                                            <option value="">اختر الطبيب</option>
                                            @foreach($doctors as $doctor)
                                                <option value="{{ $doctor->user->name }}" {{ (old('referring_doctor_name', request('referring_doctor_name')) == $doctor->user->name) ? 'selected' : '' }}>
                                                    د. {{ $doctor->user->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('referring_doctor_name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    
                                    <!-- حقل إدخال الطبيب الخارجي -->
                                    <div id="external_doctor_input" style="display: none;">
                                        <input type="text" name="referring_doctor_name" id="external_referring_doctor_name" 
                                               class="form-control form-control-lg @error('referring_doctor_name') is-invalid @enderror" 
                                               value="{{ old('referring_doctor_name') }}"
                                               placeholder="أدخل اسم الطبيب المرسل"
                                               list="external_doctors_list" disabled required>
                                        <datalist id="external_doctors_list">
                                            @php
                                                $externalDoctors = \App\Models\Surgery::whereNotNull('referring_doctor_name')
                                                    ->distinct()
                                                    ->pluck('referring_doctor_name')
                                                    ->filter()
                                                    ->unique()
                                                    ->sort();
                                            @endphp
                                            @foreach($externalDoctors as $externalDoctor)
                                                <option value="{{ $externalDoctor }}">
                                            @endforeach
                                        </datalist>
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            سيتم حفظ الاسم وعرضه كاقتراح في المرات القادمة
                                        </small>
                                        @error('referring_doctor_name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror

                                        <!-- ملف ورقة التحويل للطبيب الخارجي -->
                                        <div class="mt-3" id="referral_letter_container" style="display: none;">
                                            <label for="referral_letter" class="form-label">
                                                <i class="fas fa-file-medical-alt me-1"></i>
                                                صورة ورقة التحويل <span class="text-danger">*</span>
                                            </label>
                                            <input type="file" 
                                                   name="referral_letter" 
                                                   id="referral_letter" 
                                                   class="form-control form-control-lg @error('referral_letter') is-invalid @enderror" 
                                                   accept="image/*,application/pdf">
                                            @error('referral_letter')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div id="referral_letter_preview" class="mt-2" style="display: none;">
                                            <figure class="figure">
                                                <img src="" class="figure-img img-fluid rounded" alt="معاينة ورقة التحويل" style="max-height:200px;">
                                                <figcaption class="figure-caption text-center">معاينة ورقة التحويل</figcaption>
                                            </figure>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- الخطوة 2: التفاصيل الطبية والموعد -->
                    <div class="tab-pane fade" id="step2" role="tabpanel">
                        <h5 class="mb-4 text-success">
                            <i class="fas fa-user-md me-2"></i>
                            التفاصيل الطبية والموعد
                        </h5>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="doctor_id" class="form-label fw-bold">
                                        <i class="fas fa-user-md me-1 text-primary"></i>
                                        الطبيب الجراح <span class="text-danger">*</span>
                                    </label>
                                    <select name="doctor_id" id="doctor_id" class="form-select form-select-lg @error('doctor_id') is-invalid @enderror" required>
                                        <option value="">اختر الطبيب</option>
                                        @foreach($doctors as $doctor)
                                            <option value="{{ $doctor->id }}" {{ (old('doctor_id', request('doctor_id')) == $doctor->id) ? 'selected' : '' }}>
                                                د. {{ $doctor->user->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('doctor_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="department_id" class="form-label fw-bold">
                                        <i class="fas fa-hospital me-1 text-info"></i>
                                        القسم <span class="text-danger">*</span>
                                    </label>
                                    <select name="department_id" id="department_id" class="form-select form-select-lg @error('department_id') is-invalid @enderror" required>
                                        <option value="">اختر القسم</option>
                                        @foreach($departments as $department)
                                            <option value="{{ $department->id }}" {{ (old('department_id', request('department_id')) == $department->id) ? 'selected' : '' }}>
                                                {{ $department->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('department_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="scheduled_date" class="form-label fw-bold">
                                        <i class="fas fa-calendar me-1 text-warning"></i>
                                        تاريخ العملية <span class="text-danger">*</span>
                                    </label>
                                    <input type="date" name="scheduled_date" id="scheduled_date" 
                                           class="form-control form-control-lg @error('scheduled_date') is-invalid @enderror" 
                                           value="{{ old('scheduled_date') }}" required>
                                    @error('scheduled_date')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="scheduled_time" class="form-label fw-bold">
                                        <i class="fas fa-clock me-1 text-warning"></i>
                                        وقت العملية <span class="text-danger">*</span>
                                    </label>
                                    <input type="time" name="scheduled_time" id="scheduled_time" 
                                           class="form-control form-control-lg @error('scheduled_time') is-invalid @enderror" 
                                           value="{{ old('scheduled_time', '09:00') }}" required>
                                    @error('scheduled_time')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        @if(Auth::user()->hasRole(['admin', 'surgery_staff', 'doctor']))
                        <div class="section-divider" data-title="أطباء التخدير (اختياري)"></div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="anesthesiologist_id" class="form-label fw-bold">
                                        <i class="fas fa-syringe me-1 text-secondary"></i>
                                        الطبيب المخدر الأول
                                    </label>
                                    <select name="anesthesiologist_id" id="anesthesiologist_id" class="form-select @error('anesthesiologist_id') is-invalid @enderror">
                                        <option value="">اختر الطبيب المخدر</option>
                                        @foreach($doctors as $doctor)
                                            <option value="{{ $doctor->id }}" {{ (old('anesthesiologist_id') == $doctor->id) ? 'selected' : '' }}>
                                                د. {{ $doctor->user->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('anesthesiologist_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label for="anesthesiologist_2_id" class="form-label fw-bold">
                                        <i class="fas fa-syringe me-1 text-secondary"></i>
                                        الطبيب المخدر الثاني
                                    </label>
                                    <select name="anesthesiologist_2_id" id="anesthesiologist_2_id" class="form-select @error('anesthesiologist_2_id') is-invalid @enderror">
                                        <option value="">اختر الطبيب المخدر الثاني</option>
                                        @foreach($doctors as $doctor)
                                            <option value="{{ $doctor->id }}" {{ (old('anesthesiologist_2_id') == $doctor->id) ? 'selected' : '' }}>
                                                د. {{ $doctor->user->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('anesthesiologist_2_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>


                    <!-- الخطوة 3: اختيار الغرفة -->
                    <div class="tab-pane fade" id="step3" role="tabpanel">
                        <h5 class="mb-4 text-danger">
                            <i class="fas fa-bed me-2"></i>
                            اختيار الغرفة (اختياري)
                        </h5>
                        
                        <!-- مدة الإقامة -->
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="card border-info">
                                    <div class="card-body">
                                        <label for="expected_stay_days" class="form-label fw-bold">
                                            <i class="fas fa-calendar-day me-1 text-info"></i>
                                            مدة الإقامة المتوقعة (أيام)
                                        </label>
                                        <input type="number" name="expected_stay_days" id="expected_stay_days" 
                                               class="form-control form-control-lg @error('expected_stay_days') is-invalid @enderror"
                                               value="{{ old('expected_stay_days', 1) }}" min="1" max="365">
                                        @error('expected_stay_days')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="card border-success h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="w-100">
                                            <h6 class="text-success mb-2">
                                                <i class="fas fa-money-bill-wave me-2"></i>
                                                ملخص التكلفة
                                            </h6>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">الغرفة المختارة:</span>
                                                <span id="selected_room_name" class="fw-bold">لم يتم الاختيار</span>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center mt-2">
                                                <span class="text-muted">إجمالي أجرة الغرفة:</span>
                                                <span id="room_total_fee" class="fs-4 fw-bold text-success">0 د.ع</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- دليل الألوان -->
                        <div class="alert alert-light border mb-4">
                            <div class="row text-center">
                                <div class="col">
                                    <span class="badge bg-success me-1" style="width: 12px; height: 12px; display: inline-block;"></span>
                                    <small>متاحة</small>
                                </div>
                                <div class="col">
                                    <span class="badge bg-danger me-1" style="width: 12px; height: 12px; display: inline-block;"></span>
                                    <small>محجوزة</small>
                                </div>
                                <div class="col">
                                    <span class="badge bg-warning me-1" style="width: 12px; height: 12px; display: inline-block;"></span>
                                    <small>صيانة</small>
                                </div>
                                <div class="col">
                                    <span class="badge bg-secondary me-1" style="width: 12px; height: 12px; display: inline-block;"></span>
                                    <small>عادية</small>
                                </div>
                                <div class="col">
                                    <span class="badge bg-warning me-1" style="width: 12px; height: 12px; display: inline-block;"></span>
                                    <small>VIP</small>
                                </div>
                            </div>
                        </div>

                        <!-- حقل الغرفة المخفي -->
                        <input type="hidden" name="room_id" id="room_id" value="{{ old('room_id', '') }}">

                        <!-- لوحة الغرف -->
                        @php
                            $roomsByFloor = $rooms->groupBy('floor');
                        @endphp

                        @forelse($roomsByFloor as $floor => $floorRooms)
                        <div class="card shadow-sm mb-3">
                            <div class="card-header py-2 bg-light">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0">
                                        <i class="fas fa-layer-group me-1 text-primary"></i>
                                        {{ $floor ?: 'بدون طابق' }}
                                    </h6>
                                    <span class="badge bg-primary">{{ $floorRooms->count() }} غرفة</span>
                                </div>
                            </div>
                            <div class="card-body py-2">
                                <div class="d-flex flex-wrap gap-2">
                                    @foreach($floorRooms as $room)
                                    @php
                                        $statusColor = match($room->status) {
                                            'available' => 'success',
                                            'occupied' => 'danger',
                                            'maintenance' => 'warning',
                                            default => 'secondary'
                                        };
                                        $typeBg = $room->room_type === 'vip' ? 'bg-warning bg-opacity-10' : '';
                                        $isAvailable = $room->status === 'available';
                                    @endphp
                                    <div class="room-tile room-selectable {{ $typeBg }} {{ !$room->is_active ? 'opacity-50' : '' }} {{ !$isAvailable ? 'cursor-not-allowed' : '' }}"
                                         data-room-id="{{ $room->id }}"
                                         data-room-fee="{{ $room->daily_fee }}"
                                         data-room-type="{{ $room->room_type }}"
                                         data-room-number="{{ $room->room_number }}"
                                         data-available="{{ $isAvailable ? '1' : '0' }}"
                                         data-bs-toggle="tooltip"
                                         data-bs-html="true"
                                         title="<b>{{ $room->room_number }}</b><br>{{ $room->room_type_name }}<br>{{ number_format($room->daily_fee) }} د.ع/يوم<br>{{ $room->status_name }}"
                                         style="border-color: var(--bs-{{ $statusColor }}); {{ !$isAvailable ? 'pointer-events: none;' : 'cursor: pointer;' }}">

                                        <div class="room-number">{{ $room->room_number }}</div>

                                        <div class="room-badges">
                                            @if($room->room_type === 'vip')
                                                <span class="badge bg-warning text-dark" style="font-size: 0.6rem;">VIP</span>
                                            @endif
                                        </div>

                                        <div class="room-status">
                                            <span class="status-dot bg-{{ $statusColor }}"></span>
                                        </div>

                                        @if($isAvailable)
                                        <div class="room-actions" style="display: none;">
                                            <i class="fas fa-check-circle text-success" style="font-size: 0.8rem;"></i>
                                        </div>
                                        @endif
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        @empty
                        <div class="alert alert-info text-center">
                            <i class="fas fa-info-circle fa-2x mb-2 d-block"></i>
                            <h5>لا توجد غرف متاحة</h5>
                            <p class="mb-0">لم يتم العثور على غرف متاحة للحجز</p>
                        </div>
                        @endforelse

                        <!-- زر إلغاء اختيار الغرفة -->
                        <div class="text-center mt-4" id="clear_room_section" style="display: none;">
                            <button type="button" class="btn btn-outline-secondary" id="clear_room_btn">
                                <i class="fas fa-times me-2"></i>
                                إلغاء اختيار الغرفة
                            </button>
                        </div>
                    </div>
                </div>

                <!-- أزرار التنقل -->
                <div class="d-flex justify-content-between mt-4 pt-4 border-top">
                    <button type="button" class="btn btn-outline-secondary btn-lg" id="prevBtn" style="display: none;">
                        <i class="fas fa-arrow-right me-2"></i>
                        السابق
                    </button>
                    <div></div>
                    <div class="d-flex gap-2">
                        <a href="{{ route('surgeries.index') }}" class="btn btn-outline-danger btn-lg">
                            <i class="fas fa-times me-2"></i>
                            إلغاء
                        </a>
                        <button type="button" class="btn btn-primary btn-lg" id="nextBtn">
                            التالي
                            <i class="fas fa-arrow-left ms-2"></i>
                        </button>
                        <button type="submit" class="btn btn-success btn-lg" id="submitBtn" style="display: none;">
                            <i class="fas fa-save me-2"></i>
                            حجز العملية
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // تفعيل Select2 على جميع القوائم المنسدلة
    if (typeof $.fn.select2 !== 'undefined') {
        $('#doctor_id, #department_id, #patient_id, #referring_doctor_name_select, #anesthesiologist_id, #anesthesiologist_2_id, #surgery_category, #surgical_operation_id').select2({
            theme: 'bootstrap-5',
            dir: 'rtl',
            language: {
                noResults: function() {
                    return 'لا توجد نتائج';
                },
                searching: function() {
                    return 'جاري البحث...';
                }
            },
            placeholder: function() {
                return $(this).data('placeholder') || 'اختر...';
            },
            allowClear: true
        });
    }

    // تفعيل Tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    const tabs = document.querySelectorAll('#surgeryTabs .nav-link');
    const tabPanes = document.querySelectorAll('.tab-pane');
    const stepItems = document.querySelectorAll('.step-item');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');
    const form = document.getElementById('surgeryForm'); // main form element
    let currentStep = 0;

    const stepNames = ['المريض والعملية', 'الطبيب والموعد', 'الغرفة'];
    const progressPercentText = document.getElementById('progressPercentText');
    const progressBarFill = document.getElementById('progressBarFill');
    const currentStepNum = document.getElementById('currentStepNum');
    const stepName = document.getElementById('stepName');

    function updateUI() {
        // حساب النسبة المئوية
        const percent = Math.round(((currentStep + 1) / tabs.length) * 100);
        
        progressPercentText.textContent = percent + '% اكتمال';
        progressBarFill.style.width = percent + '%';
        currentStepNum.textContent = currentStep + 1;
        stepName.textContent = stepNames[currentStep];

        // تحديث الأزرار
        prevBtn.style.display = currentStep === 0 ? 'none' : 'inline-block';
        nextBtn.style.display = currentStep === tabs.length - 1 ? 'none' : 'inline-block';
        submitBtn.style.display = currentStep === tabs.length - 1 ? 'inline-block' : 'none';

        // تحديث التبويبات
        tabs.forEach((tab, index) => {
            if (index === currentStep) {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });

        tabPanes.forEach((pane, index) => {
            if (index === currentStep) {
                pane.classList.add('show', 'active');
            } else {
                pane.classList.remove('show', 'active');
            }
        });

        // التمرير
        if (currentStep === tabs.length - 1) {
            // final step: show submit button by scrolling down
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        } else {
            // other steps: scroll to top for clarity
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }

    // allow clicking tabs to change step
    tabs.forEach((tab, idx) => {
        tab.addEventListener('click', function() {
            currentStep = idx;
            updateUI();
        });
    });

    // next button simply advances the step
    nextBtn.addEventListener('click', function() {
        if (currentStep < tabs.length - 1) {
            currentStep++;
            updateUI();
        }
        console.log('moved to step', currentStep);
    });

    // form submission validation
    if (form) {
        form.addEventListener('submit', function(e) {
            console.log('form submit triggered, validity=', form.checkValidity());
            if (!form.checkValidity()) {
                e.preventDefault();
                form.reportValidity();
                // find first invalid input
                const invalid = form.querySelector(':invalid');
                if (invalid) {
                    // determine step of this input
                    let stepIndex = 0;
                    if (invalid.closest('#step1')) stepIndex = 0;
                    else if (invalid.closest('#step2')) stepIndex = 1;
                    else if (invalid.closest('#step3')) stepIndex = 2;
                    currentStep = stepIndex;
                    updateUI();
                    invalid.focus();
                }
            }
        });
    }

    // التحكم في حقول التحويل الخارجي
    const internalRadio = document.getElementById('referral_internal');
    const externalRadio = document.getElementById('referral_external');
    const externalFields = document.getElementById('external_fields');

    function toggleExternalFields() {
        if (externalRadio && externalRadio.checked) {
            externalFields.style.display = 'block';
        } else {
            externalFields.style.display = 'none';
        }
    }

    if (internalRadio && externalRadio) {
        internalRadio.addEventListener('change', toggleExternalFields);
        externalRadio.addEventListener('change', toggleExternalFields);
        toggleExternalFields();
    }

    // التحكم في حقول الطبيب المرسل
    const referringInternalRadio = document.getElementById('referring_internal');
    const referringExternalRadio = document.getElementById('referring_external');
    const internalDoctorSelect = document.getElementById('internal_doctor_select');
    const externalDoctorInput = document.getElementById('external_doctor_input');
    const internalDoctorNameSelect = document.getElementById('referring_doctor_name_select');
    const externalDoctorNameInput = document.getElementById('external_referring_doctor_name');

    function toggleReferringDoctorFields() {
        if (referringExternalRadio && referringExternalRadio.checked) {
            internalDoctorSelect.style.display = 'none';
            externalDoctorInput.style.display = 'block';
            // toggle disabled/required attributes
            internalDoctorSelect.disabled = true;
            internalDoctorSelect.required = false;
            externalDoctorInput.disabled = false;
            externalDoctorInput.required = true;

            if (internalDoctorNameSelect) {
                internalDoctorNameSelect.disabled = true;
            }
            if (externalDoctorNameInput) {
                externalDoctorNameInput.disabled = false;
            }
            // show referral letter upload
            const letterContainer = document.getElementById('referral_letter_container');
            if (letterContainer) letterContainer.style.display = 'block';
        } else {
            internalDoctorSelect.style.display = 'block';
            externalDoctorInput.style.display = 'none';
            internalDoctorSelect.disabled = false;
            internalDoctorSelect.required = true;
            externalDoctorInput.disabled = true;
            externalDoctorInput.required = false;

            if (internalDoctorNameSelect) {
                internalDoctorNameSelect.disabled = false;
            }
            if (externalDoctorNameInput) {
                externalDoctorNameInput.disabled = true;
            }
            const letterContainer = document.getElementById('referral_letter_container');
            if (letterContainer) letterContainer.style.display = 'none';
        }
    }

    if (referringInternalRadio && referringExternalRadio) {
        referringInternalRadio.addEventListener('change', toggleReferringDoctorFields);
        referringExternalRadio.addEventListener('change', toggleReferringDoctorFields);
        toggleReferringDoctorFields();
    }

    // if server returned validation errors, jump to the appropriate step
    function focusFirstError() {
        if (!form) return;
        const invalid = form.querySelector(':invalid');
        if (invalid) {
            let stepIndex = 0;
            if (invalid.closest('#step2')) stepIndex = 1;
            else if (invalid.closest('#step3')) stepIndex = 2;
            currentStep = stepIndex;
            updateUI();
            invalid.focus();
        }
    }

    focusFirstError();

    // preview for referral letter
    const referralInput = document.getElementById('referral_letter');
    const previewContainer = document.getElementById('referral_letter_preview');
    if (referralInput) {
        referralInput.addEventListener('change', function() {
            const file = this.files[0];
            if (!file) {
                previewContainer.style.display = 'none';
                return;
            }
            const url = URL.createObjectURL(file);
            const ext = file.name.split('.').pop().toLowerCase();
            if (file.type.startsWith('image/')) {
                previewContainer.querySelector('img').src = url;
                previewContainer.style.display = 'block';
            } else {
                previewContainer.innerHTML = `<a href="${url}" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-file-alt me-1"></i>عرض الملف</a>`;
                previewContainer.style.display = 'block';
            }
        });
    }

    // تصفية العمليات حسب الصنف المختار
    const categorySelect = document.getElementById('surgery_category');
    const operationSelect = document.getElementById('surgical_operation_id');

    function filterOperations() {
        if (!categorySelect || !operationSelect) return;

        const selectedCategory = categorySelect.value;
        const allOptions = operationSelect.querySelectorAll('option');

        allOptions.forEach(option => {
            if (!option.value) {
                option.style.display = 'block';
                return;
            }

            const optionCategory = option.dataset.category;
            if (!selectedCategory || optionCategory === selectedCategory) {
                option.style.display = 'block';
            } else {
                option.style.display = 'none';
            }
        });

        // إعادة تعيين الاختيار إذا كان غير متوافق
        const selectedOption = operationSelect.options[operationSelect.selectedIndex];
        if (selectedOption && selectedOption.dataset.category !== selectedCategory && selectedCategory) {
            operationSelect.value = '';
        }
    }

    if (categorySelect) {
        categorySelect.addEventListener('change', filterOperations);
        filterOperations(); // تطبيق التصفية عند التحميل
    }

    // اختيار الغرفة من اللوحة
    const roomTiles = document.querySelectorAll('.room-selectable');
    const roomIdInput = document.getElementById('room_id');
    const stayDaysInput = document.getElementById('expected_stay_days');
    const roomTotalFee = document.getElementById('room_total_fee');
    const selectedRoomName = document.getElementById('selected_room_name');
    const clearRoomSection = document.getElementById('clear_room_section');
    const clearRoomBtn = document.getElementById('clear_room_btn');
    let selectedRoomFee = 0;

    function selectRoom(tile) {
        // تجاهل الغرف غير المتاحة
        if (tile.dataset.available === '0') {
            return;
        }

        // إزالة التحديد من جميع البطاقات
        document.querySelectorAll('.room-tile').forEach(t => {
            t.classList.remove('border-4', 'border-primary', 'shadow-lg');
            // إخفاء جميع أيقونات التحديد
            const checkIcon = t.querySelector('.room-actions');
            if (checkIcon) {
                checkIcon.style.display = 'none';
            }
        });

        // تحديد البطاقة الحالية
        tile.classList.add('border-4', 'border-primary', 'shadow-lg');
        
        // إظهار أيقونة التحديد
        const checkIcon = tile.querySelector('.room-actions');
        if (checkIcon) {
            checkIcon.style.display = 'block';
        }

        // تحديث القيم
        const roomId = tile.dataset.roomId;
        const roomNumber = tile.dataset.roomNumber;
        const roomType = tile.dataset.roomType;
        selectedRoomFee = parseFloat(tile.dataset.roomFee);

        roomIdInput.value = roomId;
        selectedRoomName.textContent = roomNumber + (roomType === 'vip' ? ' (VIP)' : ' (عادية)');
        clearRoomSection.style.display = 'block';

        calculateRoomFee();

        // move to last step so submit button appears immediately
        currentStep = tabs.length - 1;
        updateUI();

        // if form is now valid we can auto-submit (user already filled prior steps)
        if (form.checkValidity()) {
            console.log('form valid after room select, auto-submitting');
            form.submit();
        } else {
            // focus submit button so user can click it if validation still fails
            submitBtn.focus();
        }
    }

    function clearRoomSelection() {
        // إزالة التحديد من جميع البطاقات
        document.querySelectorAll('.room-tile').forEach(t => {
            t.classList.remove('border-4', 'border-primary', 'shadow-lg');
            // إخفاء جميع أيقونات التحديد
            const checkIcon = t.querySelector('.room-actions');
            if (checkIcon) {
                checkIcon.style.display = 'none';
            }
        });

        roomIdInput.value = '';
        selectedRoomName.textContent = 'لم يتم الاختيار';
        selectedRoomFee = 0;
        clearRoomSection.style.display = 'none';

        calculateRoomFee();
    }

    function calculateRoomFee() {
        if (!stayDaysInput || !roomTotalFee) return;

        const days = parseInt(stayDaysInput.value) || 0;
        const total = selectedRoomFee * days;

        roomTotalFee.textContent = new Intl.NumberFormat('ar-IQ').format(total) + ' د.ع';
    }

    // إضافة أحداث النقر على بطاقات الغرف
    roomTiles.forEach(tile => {
        tile.addEventListener('click', function() {
            selectRoom(this);
        });
    });

    // زر إلغاء اختيار الغرفة
    if (clearRoomBtn) {
        clearRoomBtn.addEventListener('click', clearRoomSelection);
    }

    // حساب الأجرة عند تغيير عدد الأيام
    if (stayDaysInput) {
        stayDaysInput.addEventListener('input', calculateRoomFee);
    }

    // استعادة الاختيار المحفوظ
    if (roomIdInput && roomIdInput.value) {
        const savedTile = document.querySelector('.room-tile[data-room-id="' + roomIdInput.value + '"]');
        if (savedTile) {
            selectRoom(savedTile);
        }
    }

    calculateRoomFee();

    updateUI();
});
</script>
@endsection

<style>
.room-tile {
    width: 80px;
    height: 70px;
    border: 2px solid #dee2e6;
    border-radius: 8px;
    padding: 4px;
    position: relative;
    background: white;
    transition: all 0.2s ease;
    cursor: default;
}
.room-tile:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 10;
}
.room-tile.room-selectable:hover .room-actions {
    opacity: 1;
}
.room-tile.cursor-not-allowed {
    cursor: not-allowed !important;
}
.room-number {
    font-weight: bold;
    font-size: 1rem;
    text-align: center;
    color: #333;
}
.room-badges {
    text-align: center;
    min-height: 16px;
}
.room-status {
    position: absolute;
    top: 4px;
    left: 4px;
}
.status-dot {
    display: inline-block;
    width: 10px;
    height: 10px;
    border-radius: 50%;
}
.room-actions {
    position: absolute;
    bottom: 2px;
    left: 0;
    right: 0;
    text-align: center;
    opacity: 0;
    transition: opacity 0.2s ease;
    background: rgba(255,255,255,0.9);
    padding: 2px;
    border-radius: 0 0 6px 6px;
}
</style>

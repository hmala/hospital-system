<!-- resources/views/layouts/app.blade.php -->
@php
    // عدادات بسيطة للقائمة الجانبية
    $doctorIncompleteVisits = 0;
    $pendingSurgeries = 0;
    $pendingRequestsCount = 0;
    $confirmedAppointments = 0;
    $incompleteVisits = 0;
    $pendingRadiology = 0;
    $pendingLab = 0;
    $pendingSurgeryLabTests = 0;
    $waitingSurgeries = 0;

    if (Auth::check()) {
        try {
            if (Auth::user()->isAdmin() || Auth::user()->isReceptionist() || Auth::user()->isDoctor()) {
                $pendingSurgeries = \App\Models\Surgery::whereIn('status', ['scheduled', 'waiting'])->count();
            }
            if (Auth::user()->isAdmin() || Auth::user()->isReceptionist()) {
                $pendingRequestsCount = \App\Models\Request::where('status', 'pending')->count();
                $confirmedAppointments = \App\Models\Appointment::where('status', 'confirmed')->count();
                $incompleteVisits = \App\Models\Visit::whereIn('status', ['pending', 'in_progress'])->count();
                $pendingRadiology = \App\Models\RadiologyRequest::where('status', 'pending')->count();
                $pendingLab = \App\Models\LabResult::where('status', 'pending')->count();
            }
            if (Auth::user()->hasRole(['lab_staff', 'admin', 'doctor'])) {
                $pendingSurgeryLabTests = \App\Models\SurgeryLabTest::where('status', 'pending')->count();
            }
            if (Auth::user()->hasRole('surgery_staff')) {
                $waitingSurgeries = \App\Models\Surgery::where('status', 'waiting')->count();
            }
            if (Auth::user()->isDoctor()) {
                $doctorIncompleteVisits = \App\Models\Visit::where('doctor_id', Auth::id())
                    ->whereIn('status', ['pending', 'in_progress'])
                    ->count();
            }
        } catch (\Exception $e) {
            // في حالة خطأ، نترك القيم الافتراضية
        }
    }
@endphp
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>نظام المستشفى الأهلي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4-theme.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .sidebar { background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%); min-height: 100vh; box-shadow: 0 0 10px rgba(0,0,0,0.1); position: fixed; width: 250px; overflow-y: auto; }
        .sidebar .nav-link { color: #ecf0f1; padding: 12px 20px; margin: 2px 0; border-radius: 8px; transition: all 0.3s; font-size: 0.9rem; }
        .sidebar .nav-link:hover { background-color: rgba(52, 152, 219, 0.2); color: #3498db; transform: translateX(-5px); }
        .sidebar .nav-link.active { background: linear-gradient(135deg, #3498db, #2980b9); color: white; box-shadow: 0 4px 6px rgba(52, 152, 219, 0.3); }
        .sidebar-section-title { color: #bdc3c7; font-size: 0.85rem; font-weight: 600; padding: 12px 20px; margin-top: 10px; cursor: pointer; background: rgba(52, 152, 219, 0.1); border-radius: 8px; transition: all 0.3s; display: flex; justify-content: space-between; align-items: center; }
        .sidebar-section-title:hover { background: rgba(52, 152, 219, 0.2); color: #3498db; }
        .sidebar-section-title i.toggle-icon { transition: transform 0.3s; font-size: 0.8rem; }
        .sidebar-section-title.collapsed i.toggle-icon { transform: rotate(-90deg); }
        .sidebar-divider { border-top: 1px solid rgba(255,255,255,0.1); margin: 10px 15px; }
        .collapse-section { padding-right: 0; }
        .main-content { margin-right: 250px; padding: 20px; transition: all 0.3s; }
        .stat-card { border-radius: 15px; border: none; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: transform 0.3s; }
        .stat-card:hover { transform: translateY(-5px); }
        .bg-patient { background: linear-gradient(45deg, #3498db, #2980b9); }
        .bg-doctor { background: linear-gradient(45deg, #27ae60, #2ecc71); }
        .bg-department { background: linear-gradient(45deg, #e74c3c, #c0392b); }
        .bg-appointment { background: linear-gradient(45deg, #f39c12, #e67e22); }
        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar .nav-link span { display: none; }
            .sidebar-section-title { display: none; }
            .main-content { margin-right: 70px; }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- الشريط الجانبي -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar">
                <div class="position-sticky pt-0">
                    <div class="sidebar-header text-center p-3 border-bottom border-secondary">
                        <i class="fas fa-hospital-alt fa-2x text-white mb-2"></i>
                        <h5 class="text-white mb-0">المستشفى الأهلي</h5>
                    </div>

                    <!-- روابط ثابتة حسب الصلاحيات -->
                        
                        @canany(['view patients','view inquiries','view cashier'])
                        <div class="sidebar-divider"></div>
                        <div class="sidebar-section-title collapsed" data-bs-toggle="collapse" data-bs-target="#patientMgmtSection" aria-expanded="false">
                            <span><i class="fas fa-user-injured"></i> إدارة المرضى</span>
                            <i class="fas fa-chevron-down toggle-icon"></i>
                        </div>
                        <div class="collapse collapse-section" id="patientMgmtSection">
                        @role('admin|receptionist|emergency_staff')
                        @can('view patients')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('patients.*') ? 'active' : '' }}" href="{{ route('patients.index') }}">
                                <i class="fas fa-user-injured"></i><span> المرضى</span>
                            </a>
                        </li>
                        @endcan
                        @can('view inquiries')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('inquiry.*') ? 'active' : '' }}" href="{{ route('inquiry.index') }}">
                                <i class="fas fa-concierge-bell"></i><span> الاستعلامات</span>
                                <span class="badge bg-secondary ms-2">{{ $pendingRequestsCount }}</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        @role('admin|cashier|receptionist')
                        @can('view cashier')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('cashier.index') || request()->routeIs('cashier.payment.*') || request()->routeIs('cashier.receipt*') ? 'active' : '' }}" href="{{ route('cashier.index') }}">
                                <i class="fas fa-cash-register"></i><span> الكاشير</span>
                                @php
                                    $pendingPayments = \App\Models\Appointment::where('payment_status', 'pending')
                                        ->whereIn('status', ['scheduled', 'confirmed'])
                                        ->count();
                                @endphp
                                @if($pendingPayments > 0)
                                    <span class="badge bg-warning ms-2">{{ $pendingPayments }}</span>
                                @endif
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('cashier.report') ? 'active' : '' }}" href="{{ route('cashier.report') }}">
                                <i class="fas fa-file-invoice-dollar"></i><span> سجل الفواتير</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('cashier.surgeries.*') ? 'active' : '' }}" href="{{ route('cashier.surgeries.index') }}">
                                <i class="fas fa-procedures text-danger"></i><span> كاشير العمليات</span>
                                @php
                                    $pendingSurgeryPayments = \App\Models\Surgery::whereIn('payment_status', ['pending', 'partial'])
                                        ->whereIn('status', ['scheduled', 'waiting'])
                                        ->count();
                                @endphp
                                @if($pendingSurgeryPayments > 0)
                                    <span class="badge bg-danger ms-2">{{ $pendingSurgeryPayments }}</span>
                                @endif
                            </a>
                        </li>
                        @endcan
                        @endrole
                        </div> <!-- end patientMgmtSection -->
                        @endcanany

                        @role('admin|patient')
                        @can('view own visits')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('patient.visits.*') ? 'active' : '' }}" href="{{ route('patient.visits.index') }}">
                                <i class="fas fa-file-medical"></i><span> زياراتي</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        @role('admin|receptionist|patient')
                        </div>
                        @endrole

                        <!-- قسم الطوارئ -->
                        @php
                            $showEmergencySection = false;
                            if ($user = auth()->user()) {
                                if ($user->hasAnyRole(['admin','doctor','nurse','receptionist','emergency_staff'])) {
                                    $showEmergencySection = true;
                                }
                                if ($user->can('view emergencies') || $user->can('create emergencies')) {
                                    $showEmergencySection = true;
                                }
                            }
                        @endphp
                        @if($showEmergencySection)
                        <div class="sidebar-divider"></div>
                        <div class="sidebar-section-title collapsed" data-bs-toggle="collapse" data-bs-target="#emergencySection" aria-expanded="false">
                            <span><i class="fas fa-ambulance"></i> الطوارئ</span>
                            <i class="fas fa-chevron-down toggle-icon"></i>
                        </div>
                        <div class="collapse collapse-section" id="emergencySection">
                        @can('view emergencies')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('emergency.index') ? 'active' : '' }}" href="{{ route('emergency.index') }}">
                                <i class="fas fa-list"></i><span> حالات الطوارئ</span>
                                @php
                                    $criticalEmergencies = \App\Models\Emergency::where('priority', 'critical')
                                        ->whereNotIn('status', ['discharged', 'transferred'])
                                        ->count();
                                @endphp
                                @if($criticalEmergencies > 0)
                                    <span class="badge bg-danger ms-2">{{ $criticalEmergencies }}</span>
                                @endif
                            </a>
                        </li>
                        @endcan
                        @can('view emergencies')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('emergency.patients.*') ? 'active' : '' }}" href="{{ route('emergency.patients.index') }}">
                                <i class="fas fa-user-injured"></i><span> مرضى الطوارئ</span>
                            </a>
                        </li>
                        @endcan
                        @can('create emergencies')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('emergency.create') ? 'active' : '' }}" href="{{ route('emergency.create') }}">
                                <i class="fas fa-plus"></i><span> إضافة حالة طوارئ</span>
                            </a>
                        </li>
                        @endcan
                        </div>
                        @endif

                        <!-- قسم الأطباء والعيادات -->
                        @php
                            $showDoctorSection = auth()->user() && (
                                auth()->user()->can('view doctors') ||
                                auth()->user()->can('view departments') ||
                                auth()->user()->can('manage own visits') ||
                                auth()->user()->hasRole('consultation_receptionist')
                            );
                        @endphp
                        @if($showDoctorSection)
                        <div class="sidebar-divider"></div>
                        <div class="sidebar-section-title collapsed" data-bs-toggle="collapse" data-bs-target="#doctorSection" aria-expanded="false">
                            <span><i class="fas fa-stethoscope"></i> الأطباء والعيادات</span>
                            <i class="fas fa-chevron-down toggle-icon"></i>
                        </div>
                        <div class="collapse collapse-section" id="doctorSection">

                        @role('admin|receptionist')
                        @can('view doctors')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('doctors.*') ? 'active' : '' }}" href="{{ route('doctors.index') }}">
                                <i class="fas fa-user-md"></i><span> الأطباء</span>
                            </a>
                        </li>
                        @endcan
                        @can('view departments')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('departments.*') ? 'active' : '' }}" href="{{ route('departments.admin') }}">
                                <i class="fas fa-clinic-medical"></i><span> العيادات</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        @hasrole('consultation_receptionist')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('consultant-availability.*') ? 'active' : '' }}" href="{{ route('consultant-availability.index') }}">
                                <i class="fas fa-calendar-check"></i><span> توفر الأطباء الاستشاريين</span>
                            </a>
                        </li>
                        @endhasrole

                        @role('admin|patient')
                        @can('view departments')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('departments.public') ? 'active' : '' }}" href="{{ route('departments.public') }}">
                                <i class="fas fa-clinic-medical"></i><span> العيادات</span>
                            </a>
                        </li>
                        @endcan
                        @can('view doctors')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('doctors.index') ? 'active' : '' }}" href="{{ route('doctors.index') }}">
                                <i class="fas fa-user-md"></i><span> الأطباء</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        @role('admin|doctor')
                        @can('manage own visits')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('doctor.visits.*') ? 'active' : '' }}" href="{{ route('doctor.visits.index') }}">
                                <i class="fas fa-user-md"></i><span> زياراتي</span>
                                <span class="badge bg-secondary ms-2">{{ $doctorIncompleteVisits }}</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        </div>
                        @endif

                        <!-- قسم المواعيد والزيارات -->
                        @php
                            $showAppointmentSection = false;
                            if ($user = auth()->user()) {
                                // only show when there will be at least one visible link
                                if ($user->hasAnyRole(['admin','receptionist']) &&
                                    ($user->can('view appointments') || $user->can('view visits'))
                                ) {
                                    $showAppointmentSection = true;
                                }
                                if ($user->hasAnyRole(['admin','patient']) &&
                                    $user->can('create appointments')
                                ) {
                                    $showAppointmentSection = true;
                                }
                            }
                        @endphp
                        @if($showAppointmentSection)
                        <div class="sidebar-divider"></div>
                        <div class="sidebar-section-title collapsed" data-bs-toggle="collapse" data-bs-target="#appointmentSection" aria-expanded="false">
                            <span><i class="fas fa-calendar-alt"></i> المواعيد والزيارات</span>
                            <i class="fas fa-chevron-down toggle-icon"></i>
                        </div>
                        <div class="collapse collapse-section" id="appointmentSection">

                        @role('admin|receptionist')
                        @can('view appointments')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('appointments.*') ? 'active' : '' }}" href="{{ route('appointments.index') }}">
                                <i class="fas fa-calendar-check"></i><span> المواعيد</span>
                                <span class="badge bg-secondary ms-2">{{ $confirmedAppointments }}</span>
                            </a>
                        </li>
                        @endcan
                        @can('view visits')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('visits.*') ? 'active' : '' }}" href="{{ route('visits.index') }}">
                                <i class="fas fa-file-medical"></i><span> الزيارات</span>
                                <span class="badge bg-secondary ms-2">{{ $incompleteVisits }}</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        @role('admin|patient')
                        @can('create appointments')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('appointments.*') ? 'active' : '' }}" href="{{ route('appointments.index') }}">
                                <i class="fas fa-calendar-plus"></i><span> حجز موعد</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        </div>
                        @endif

                        <!-- قسم العمليات الجراحية -->
                        @php
                            $showSurgerySection = auth()->user() && (
                                auth()->user()->can('view surgeries') ||
                                auth()->user()->can('manage rooms') ||
                                auth()->user()->can('manage surgery fees')
                            );
                            // إخفاء قسم العمليات للأطباء الاستشاريين
                            if (auth()->user() && auth()->user()->hasRole('doctor') && auth()->user()->doctor && auth()->user()->doctor->type === 'consultant') {
                                $showSurgerySection = false;
                            }
                        @endphp
                        @if($showSurgerySection)
                        <div class="sidebar-divider"></div>
                        <div class="sidebar-section-title collapsed" data-bs-toggle="collapse" data-bs-target="#surgerySection" aria-expanded="false">
                            <span><i class="fas fa-procedures"></i> العمليات الجراحية</span>
                            <i class="fas fa-chevron-down toggle-icon"></i>
                        </div>
                        <div class="collapse collapse-section" id="surgerySection">
                        @endif

                        @role('admin|receptionist|doctor|surgery_staff')
                        @can('view surgeries')
                        @php
                            $showSurgeryLink = true;
                            // إخفاء رابط العمليات للأطباء الاستشاريين
                            if (auth()->user()->hasRole('doctor') && auth()->user()->doctor && auth()->user()->doctor->type === 'consultant') {
                                $showSurgeryLink = false;
                            }
                        @endphp
                        @if($showSurgeryLink)
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('surgeries.*') ? 'active' : '' }}" href="{{ route('surgeries.index') }}">
                                <i class="fas fa-procedures"></i><span> العمليات</span>
                                <span class="badge bg-secondary ms-2">{{ $pendingSurgeries }}</span>
                            </a>
                        </li>
                        @endif
                        @endcan
                        @endrole



                        @can('manage rooms')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('rooms.*') ? 'active' : '' }}" href="{{ route('rooms.index') }}">
                                <i class="fas fa-bed text-danger"></i><span> إدارة الغرف</span>
                            </a>
                        </li>
                        @endcan

                        @role('admin')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('surgical-operations.*') ? 'active' : '' }}" href="{{ route('surgical-operations.index') }}">
                                <i class="fas fa-money-bill-wave text-success"></i><span> إدارة أجور العمليات</span>
                            </a>
                        </li>
                        @endrole

                        @role('admin|receptionist|doctor|surgery_staff')
                        </div>
                        @endrole

                        <!-- قسم المختبر والأشعة -->
                        @php
                            $showLabSection = false;
                            if ($user = auth()->user()) {
                                // link: radiology (admin or receptionist)
                                if ($user->hasAnyRole(['admin','receptionist']) && $user->can('view radiology')) {
                                    $showLabSection = true;
                                }
                                // link: create lab visits (admin or receptionist)
                                if ($user->hasAnyRole(['admin','receptionist']) && $user->can('create lab tests')) {
                                    $showLabSection = true;
                                }
                                // link: pharmacy staff requests
                                if ($user->hasRole('pharmacy_staff')) {
                                    $showLabSection = true;
                                }
                                // link: lab staff see lab tests
                                if ($user->hasRole('lab_staff') && $user->can('view lab tests')) {
                                    $showLabSection = true;
                                }
                                // link: radiology staff see radiology requests
                                if ($user->hasRole('radiology_staff') && $user->can('view radiology')) {
                                    $showLabSection = true;
                                }
                                // link: manage surgery lab tests
                                if ($user->hasAnyRole(['admin','lab_staff','receptionist']) && $user->can('manage surgery lab tests')) {
                                    $showLabSection = true;
                                }
                                // link: surgery radiology tests
                                if ($user->hasAnyRole(['radiology_staff','admin','doctor']) && $user->can('view radiology')) {
                                    $showLabSection = true;
                                }
                                // link: waiting list (admin|surgery_staff|receptionist) handled earlier in its own section but still counts
                                if ($user->hasAnyRole(['admin','surgery_staff','receptionist']) && $user->can('view surgeries')) {
                                    $showLabSection = true;
                                }
                            }
                            // إخفاء قسم المختبر والأشعة للأطباء الاستشاريين
                            if (auth()->user() && auth()->user()->hasRole('doctor') && auth()->user()->doctor && auth()->user()->doctor->type === 'consultant') {
                                $showLabSection = false;
                            }
                        @endphp
                        @if($showLabSection)
                        <div class="sidebar-divider"></div>
                        <div class="sidebar-section-title collapsed" data-bs-toggle="collapse" data-bs-target="#labSection" aria-expanded="false">
                            <span><i class="fas fa-microscope"></i> المختبر والأشعة</span>
                            <i class="fas fa-chevron-down toggle-icon"></i>
                        </div>
                        <div class="collapse collapse-section" id="labSection">
                        @endif

                        @role('admin|receptionist')
                        @can('view radiology')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('radiology.*') ? 'active' : '' }}" href="{{ route('radiology.index') }}">
                                <i class="fas fa-x-ray"></i><span> الإشعة</span>
                                <span class="badge bg-secondary ms-2">{{ $pendingRadiology }}</span>
                            </a>
                        </li>
                        @endcan
                        @can('create lab tests')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('staff.lab-visits.*') ? 'active' : '' }}" href="{{ route('staff.lab-visits.create') }}">
                                <i class="fas fa-flask"></i><span> زيارة مختبرية</span>
                            </a>
                        </li>
                        @endcan
                        @endrole
                        @role('admin|surgery_staff|receptionist')
                        @php
                            $showWaitingListLink = true;
                            // إخفاء رابط قائمة الانتظار للأطباء الاستشاريين
                            if (auth()->user()->hasRole('doctor') && auth()->user()->doctor && auth()->user()->doctor->type === 'consultant') {
                                $showWaitingListLink = false;
                            }
                        @endphp
                        @if($showWaitingListLink)
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('surgeries.waiting') ? 'active' : '' }}" href="{{ route('surgeries.waiting') }}">
                                <i class="fas fa-clock"></i><span> قائمة الانتظار</span>
                                @if($waitingSurgeries > 0)
                                <span class="badge bg-warning ms-2">{{ $waitingSurgeries }}</span>
                                @endif
                            </a>
                        </li>
                        @endif
                        @endrole
                        @role('admin|pharmacy_staff')
                        @php
                            $staffType = null;
                            if (Auth::user()->hasRole('pharmacy_staff')) $staffType = 'pharmacy';
                        @endphp
                        @if($staffType)
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('staff.requests.*') ? 'active' : '' }}" href="{{ route('staff.requests.index') }}">
                                <i class="fas fa-tasks"></i><span> الطلبات</span>
                            </a>
                        </li>
                        @endif
                        @endrole

                        @role('lab_staff')
                        @can('view lab tests')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('staff.requests.*') ? 'active' : '' }}" href="{{ route('staff.requests.index', ['type' => 'lab']) }}">
                                <i class="fas fa-flask"></i><span> طلبات المختبر</span>
                                <span class="badge bg-secondary ms-2">{{ $pendingLab }}</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        @role('radiology_staff')
                        @can('view radiology')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('radiology.*') ? 'active' : '' }}" href="{{ route('radiology.index') }}">
                                <i class="fas fa-x-ray"></i><span> طلبات الأشعة</span>
                                <span class="badge bg-secondary ms-2">{{ $pendingRadiology }}</span>
                            </a>
                        </li>
                        @endcan
                        @endrole

                        @role('admin|lab_staff|receptionist')
                        @can('manage surgery lab tests')
                        @php
                            $showSurgeryLabLink = true;
                            // إخفاء رابط تحاليل العمليات للأطباء الاستشاريين
                            if (auth()->user()->hasRole('doctor') && auth()->user()->doctor && auth()->user()->doctor->type === 'consultant') {
                                $showSurgeryLabLink = false;
                            }
                        @endphp
                        @if($showSurgeryLabLink)
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('staff.surgery-lab-tests.*') ? 'active' : '' }}" href="{{ route('staff.surgery-lab-tests.index') }}">
                                <i class="fas fa-flask"></i><span> تحاليل العمليات</span>
                                <span class="badge bg-secondary ms-2">{{ $pendingSurgeryLabTests }}</span>
                            </a>
                        </li>
                        @endif
                        @endcan
                        @endrole

                        @role('radiology_staff|admin|doctor')
                        @can('view radiology')
                        @php
                            $showSurgeryRadiologyLink = true;
                            // إخفاء رابط أشعة العمليات للأطباء الاستشاريين
                            if (auth()->user()->hasRole('doctor') && auth()->user()->doctor && auth()->user()->doctor->type === 'consultant') {
                                $showSurgeryRadiologyLink = false;
                            }
                        @endphp
                        @if($showSurgeryRadiologyLink)
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('staff.surgery-radiology-tests.*') ? 'active' : '' }}" href="{{ route('staff.surgery-radiology-tests.index') }}">
                                <i class="fas fa-x-ray"></i><span> أشعة العمليات</span>
                            </a>
                        </li>
                        @endif
                        @endcan
                        @endrole

                        @if(isset($showLabSection) && $showLabSection)
                        </div>
                        @endif

                        <!-- قسم الإعدادات -->
                        @php
                            $showSettingsSection = auth()->user() && (
                                auth()->user()->hasRole('admin') ||
                                auth()->user()->can('manage radiology types') ||
                                auth()->user()->can('view lab tests')
                            );
                        @endphp
                        @if($showSettingsSection)
                        <div class="sidebar-divider"></div>
                        <div class="sidebar-section-title collapsed" data-bs-toggle="collapse" data-bs-target="#settingsSection" aria-expanded="false">
                            <span><i class="fas fa-cog"></i> الإعدادات</span>
                            <i class="fas fa-chevron-down toggle-icon"></i>
                        </div>
                        <div class="collapse collapse-section" id="settingsSection">

                        @role('admin')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('users.*') ? 'active' : '' }}" href="{{ route('users.index') }}">
                                <i class="fas fa-users-cog"></i><span> إدارة المستخدمين</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('roles.*') ? 'active' : '' }}" href="{{ route('roles.index') }}">
                                <i class="fas fa-user-shield"></i><span> إدارة الأدوار</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('permissions.*') ? 'active' : '' }}" href="{{ route('permissions.index') }}">
                                <i class="fas fa-key"></i><span> إدارة الصلاحيات</span>
                            </a>
                        </li>
                        @endrole

                        @can('manage radiology types')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('radiology.types.*') ? 'active' : '' }}" href="{{ route('radiology.types.index') }}">
                                <i class="fas fa-cogs"></i><span> أنواع الإشعة</span>
                            </a>
                        </li>
                        @endcan
                        @can('view lab tests')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('lab-tests.*') ? 'active' : '' }}" href="{{ route('lab-tests.index') }}">
                                <i class="fas fa-flask"></i><span> أنواع التحاليل</span>
                            </a>
                        </li>
                        @endcan
                        @endif
                    <!-- نهاية القائمة القديمة -->
                </div>
            </nav>

            <!-- المحتوى الرئيسي -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <!-- شريط التنقل العلوي -->
                <nav class="navbar navbar-expand-lg navbar-light bg-white rounded shadow-sm mb-4">
                    <div class="container-fluid">
                        <div class="navbar-nav ms-auto">
                            <!-- قائمة المستخدم -->
                            <div class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-user-circle me-2"></i>{{ Auth::user()->name }}
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="dropdown-item text-danger" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            <i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج
                                        </a>
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">@csrf</form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>

                <!-- محتوى الصفحة -->
                @yield('content')
            </main>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        // إعدادات toastr
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": true,
            "progressBar": true,
            "positionClass": "toast-top-left",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut",
            "rtl": true
        };
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    @yield('scripts')
    <script>
        // تحديث أيقونات القوائم المنسدلة
        document.addEventListener('DOMContentLoaded', function() {
            const collapsibles = document.querySelectorAll('[data-bs-toggle="collapse"]');
            collapsibles.forEach(function(element) {
                const targetId = element.getAttribute('data-bs-target');
                const target = document.querySelector(targetId);
                
                if (target) {
                    target.addEventListener('show.bs.collapse', function() {
                        element.classList.remove('collapsed');
                    });
                    
                    target.addEventListener('hide.bs.collapse', function() {
                        element.classList.add('collapsed');
                    });
                }
            });
        });

        function reloadRealtimeSections() {
            $('.realtime-section').each(function() {
                var section = $(this);
                var url = section.data('url') || window.location.href;
                $.ajax({
                    url: url,
                    type: 'GET',
                    dataType: 'html',
                    success: function(data) {
                        var newContent = $(data).find('.realtime-section[data-section="' + section.data('section') + '"]').html();
                        if(newContent) section.html(newContent);
                    }
                });
            });
        }
        setInterval(reloadRealtimeSections, 5000); // كل 5 ثواني
    </script>
</body>
</html>
